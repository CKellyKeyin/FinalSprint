if (process.env.NODE_ENV !== "production") {
  require("dotenv").config();
}
const express = require("express");
const bcrypt = require("bcrypt");
const passport = require("passport");
const localStrategy = require("passport-local").Strategy;
const flash = require("express-flash");
const session = require("express-session");
const methodOverride = require("method-override");
const uuid = require("uuid");
const logins = require("./services/plogins");
const pgs = require("./services/pgsearch.dal");
// const logins = require("./services/mlogins");
const app = express();
// const router = require("./routes/mongoSearch")

passport.use(
  new localStrategy(
    { usernameField: "email" },
    async (email_address, password, done) => {
      let user = await logins.getLoginByEmail(email_address);
      if (user == null) {
        return done(null, false, { messages: "No user with that email!" });
      }
      try {
        if (await bcrypt.compare(password, user.password)) {
          return done(null, user);
        } else {
          return done(null, false, { messages: "Incorrect password!" });
        }
      } catch (error) {
        return done(error);
      }
    }
  )
);
passport.serializeUser((user, done) => {
  done(null, user.uuid);
});
passport.deserializeUser(async (id, done) => {
  let user = await logins.getLoginById(id);
  done(null, user);
});

function checkAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.redirect("/login");
}

function checkNotAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return res.redirect("/");
  }
  return next();
}

app.set("view-engine", "ejs");
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(flash());
app.use(
  session({
    secret: "SOME_SECRET", //process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
  })
);
app.use(passport.initialize());
app.use(passport.session());

app.use(methodOverride("_method"));

app.get("/", checkAuthenticated, (req, res) => {
  res.render("search.ejs", { name: req.user.username });
});

app.get("/login", checkNotAuthenticated, (req, res) => {
  res.render("login.ejs");
});

app.post(
  "/login",
  checkNotAuthenticated,
  passport.authenticate("local", {
    successRedirect: "/",
    failureRedirect: "/login",
    failureFlash: true,
  })
);

app.get("/register", checkNotAuthenticated, (req, res) => {
  res.render("register.ejs");
});

app.post("/register", checkNotAuthenticated, async (req, res) => {
  try {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    //REWRITE THIS TO MAKE A DB QUERY THAT ADDS THE USER TO THE DATABASE
    let result = await logins.addLogin(
      req.body.name,
      req.body.email,
      hashedPassword,
      uuid.v4()
    );
    res.redirect("/login");
  } catch (error) {
    console.log(error);
    res.redirect("/register");
  }
});
app.get("/search", (req, res) => {
  res.render("search"); //{ name: 'Ciaran'}
});

app.get("/results", (req, res) => {
  res.render("results"); //{ name: 'Ciaran'}
});

app.delete("/logout", (req, res) => {
  req.logOut();
  res.redirect("login");
});
app.use(express.urlencoded({ extended: true }));
app.set("view engine", "ejs");

const mongoSearchRouter = require("./routes/mongoSearch");
app.use("/search", mongoSearchRouter);

app.get("/login", async (req, res) => {
  var queryStr = require("url").parse(req.url, true).query;
  if (queryStr.email) {
    var results = await logins.getLoginByEmail(queryStr.email_address);
  } else {
    var results = await logins.getLogin();
  }
  if (results == null) {
    console.log("no results found");
  } else {
    res.status(200).json(results);
  }
});

app.get("/login/:id", async (req, res) => {
  let result = await logins.getLoginById(req.params.login_id);
  if (result == null) {
    console.log("no results found");
  } else {
    console.log(result);
    res.json({
      info: `login ` + result.name + ` was found with pk: ` + result.login_id,
    });
  }
});

app.get("/create", async (req, res) => {
  var queryStr = require("url").parse(req.url, true).query;
  const hashedPassword = await bcrypt.hash(queryStr.password, 10);
  if (queryStr.email_address && queryStr.username && queryStr.password) {
    var result = await logins.addLogin(
      queryStr.username,
      queryStr.email_address,
      hashedPassword,
      uuid.v4()
    );
  } else {
    console.log("Not enough string parameters.");
  }

  if (result == null) {
    console.log("Unsuccessful in add.");
  } else {
    console.log(result);
    res.json({
      info:
        `A new login ` +
        queryStr.username +
        ` was created with the  _id: ` +
        result,
    });
  }
});

const knex = require("knex")({
  client: "pg",
  connection: {
    host: "127.0.0.1",
    user: "postgres",
    password: "Astronautic3",
    database: "Dogs",
    port: 5432,
  },
});

app.get("/postgres", (req, res) => {
  knex
    .select()
    .from("information")
    .then((results) => {
      res.render("postgres", { aInformation: results });
    });
});

app.listen(3000);
