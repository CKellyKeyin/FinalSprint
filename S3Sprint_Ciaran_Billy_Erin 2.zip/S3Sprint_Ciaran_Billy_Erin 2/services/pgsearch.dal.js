const dal = require("./pdb");

var getBreedById = function (breed_id) {
  return new Promise(function (resolve, reject) {
    const sql = "SELECT * FROM vw_search_id WHERE breed_id = $1";
    dal.query(sql, [breed_id], (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result.rows);
      }
    });
  });
};

var getHeightById = function (height) {
  return new Promise(function (resolve, reject) {
    const sql = "SELECT * FROM vw_search_id WHERE height = $1";
    dal.query(sql, [height], (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result.rows);
      }
    });
  });
};
var getWeightById = function (weight) {
  return new Promise(function (resolve, reject) {
    const sql = "SELECT * FROM vw_search_id WHERE weight = $1";
    dal.query(sql, [weight], (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result.rows);
      }
    });
  });
};
var getLifeExpectancyById = function (life_expectancy) {
  return new Promise(function (resolve, reject) {
    const sql = "SELECT * FROM vw_search_id WHERE life_expectancy = $1";
    dal.query(sql, [life_expectancy], (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result.rows);
      }
    });
  });
};
var getNameById = function (name) {
  return new Promise(function (resolve, reject) {
    const sql = "SELECT * FROM vw_search_id WHERE name = $1";
    dal.query(sql, [name], (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result.rows);
      }
    });
  });
};
var getScientificNameById = function (scientific_name) {
  return new Promise(function (resolve, reject) {
    const sql = "SELECT * FROM vw_search_id WHERE scientific_name = $1";
    dal.query(sql, [scientific_name], (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result.rows);
      }
    });
  });
};
var getCountryById = function (country) {
  return new Promise(function (resolve, reject) {
    const sql = "SELECT * FROM vw_search_id WHERE Country = $1";
    dal.query(sql, [country], (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result.rows);
      }
    });
  });
};

module.exports = {
  getBreedById,
  getHeightById,
  getWeightById,
  getLifeExpectancyById,
  getNameById,
  getScientificNameById,
  getCountryById,
};
