const Pool = require("pg").Pool;
// const pool = new Pool({
//   user: process.env.PGUSER,
//   host: process.env.PGHOST,
//   database: process.env.PGDATABASE,
//   password: process.env.PGPASSWORD,
//   port: process.env.PGPORT,
// });

// const knex = require("knex")({
//   client: "pg",
//   connection: {
//     host: "127.0.0.1",
//     user: "postgres",
//     password: "Keyin2021",
//     database: "Dogs",
//     port: 5432,
//   },
// });

const pool = new Pool({
  user: "postgres",
  host: "127.0.0.1",
  database: "Dogs",
  password: "Astronautic3",
  port: 5432,
});

module.exports = pool;
