const { MongoClient } = require('mongodb');
const uri = "mongodb://localhost:27017/";
const client = new MongoClient(uri);

async function getEverything() {
    await client.connect();
    const cursor = client.db("sprint").collection("dogs").find();
    const results = await cursor.toArray();

  
    return results;
};

async function getByBreedName(breedName) {
    await client.connect();
    const cursor = client.db("sprint").collection("dogs").find({breed_name: breedName});
    const results = await cursor.toArray();

    return results;
    
};

async function getByScientificName(scientificName) {
    await client.connect();
    const cursor = client.db("sprint").collection("dogs").find({scientific_name: scientificName});
    const results = await cursor.toArray();

    return results;
    
};

async function getByCountry(country) {
    await client.connect();
    const cursor = client.db("sprint").collection("dogs").find({country_of_origin: country});
    const results = await cursor.toArray();

    return results;
    
};

// async function getByRole(breedRole) {
//     await client.connect();
//     const cursor = client.db("sprint").collection("dogs").find({role: breedRole});
//     const results = await cursor.toArray();

//     return results;
    
// };










module.exports = {
    getEverything,
    getByBreedName,
    getByScientificName,
    getByCountry,
    // getByRole

}

