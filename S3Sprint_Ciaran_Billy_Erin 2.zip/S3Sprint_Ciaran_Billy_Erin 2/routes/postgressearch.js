const express = require("express");
const router = express.Router();
router.use(express.static("public"));

const pgsearchDal = require('services/pgsearch.dal')

router.get('/', async (req, res) => {
    console.log(req.method);
    let languages = await pgsearchDal.getBreedById();
    if (languages.length === 0)
        res.render('norecord');
    else {
        res.render('results.ejs', {languages, theLanguage: 'New'});
    }
});

