const express = require('express');
const router = express.Router();

const { getEverything, getByBreedName, getByScientificName, getByCountry } = require('../services/mongoSearch.dal')



router.post('/', async (req, res) => {
    let results = await getByBreedName(req.body.search_term);
    // let results = await getEverything();
       //console.log(results);
    
        res.render('results',{results});//
    });

    router.post('/', async (req, res) => {
        let results = await getByScientificName(req.body.search_term);
        // let results = await getEverything();
           //console.log(results);
        
            res.render('results',{results});//
        });

router.post('/', async (req, res) => {
    let results = await getByCountry(req.body.search_term);
    // let results = await getEverything();
       //console.log(results);
    
        res.render('results',{results});//
    });

    module.exports = router;