-- Database: Dogs

-- DROP DATABASE IF EXISTS "Dogs";

CREATE DATABASE "Dogs"
    WITH 
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'C'
    LC_CTYPE = 'C'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1;