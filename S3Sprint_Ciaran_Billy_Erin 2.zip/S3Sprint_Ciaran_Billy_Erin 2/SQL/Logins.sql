-- Table: public.Logins

-- DROP TABLE IF EXISTS public."Logins";

CREATE TABLE IF NOT EXISTS public."Logins"
(
    username character varying(1000) COLLATE pg_catalog."default",
    email character varying(1000) COLLATE pg_catalog."default",
    password character varying(1000) COLLATE pg_catalog."default",
    uuid character varying(1000) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT "Logins_pkey" PRIMARY KEY (uuid)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Logins"
    OWNER to postgres;