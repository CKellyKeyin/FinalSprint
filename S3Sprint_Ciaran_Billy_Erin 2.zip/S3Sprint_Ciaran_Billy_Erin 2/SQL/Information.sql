-- Table: public.information

-- DROP TABLE IF EXISTS public.information;

CREATE TABLE IF NOT EXISTS public.information
(
    breed_id integer NOT NULL,
    height integer NOT NULL,
    weight integer NOT NULL,
    life_expectancy integer NOT NULL,
    name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    scientific_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    country character varying(50) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT information_pkey PRIMARY KEY (breed_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.information
    OWNER to postgres;